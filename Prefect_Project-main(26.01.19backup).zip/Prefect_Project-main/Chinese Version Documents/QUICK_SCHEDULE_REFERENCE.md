# 📅 定时任务快速参考

## 🎯 你的定时任务配置

### 执行计划

| # | Flow | 时间 | Cron 表达式 |
|---|------|------|-----------|
| 1️⃣ | currency-acquisition | 09:00 | `0 9 15,25,28,29,30,31 * *` |
| 2️⃣ | prepare-batch | 09:30 | `30 9 15,25,28,29,30,31 * *` |
| 3️⃣ | process-batch | 10:00 | `0 10 15,25,28,29,30,31 * *` |

**触发日期**: 每月 **15、25、28、29、30、31** 号

**时区**: Asia/Shanghai（根据需要调整）

---

## 🚀 快速设置步骤

### 1️⃣ 打开 Prefect Cloud
```
https://app.prefect.cloud
```

### 2️⃣ 为每个 Flow 添加 Schedule

对于 **currency_acquisition_flow**:
```
Cron: 0 9 15,25,28,29,30,31 * *
Timezone: Asia/Shanghai
Description: 每月获取汇率数据
```

对于 **prepare_batch_flow**:
```
Cron: 30 9 15,25,28,29,30,31 * *
Timezone: Asia/Shanghai
Description: 每月准备批处理
```

对于 **process_batch_flow**:
```
Cron: 0 10 15,25,28,29,30,31 * *
Timezone: Asia/Shanghai
Description: 每月处理批数据
```

### 3️⃣ 启用并保存

- ✅ 勾选启用（Enable）
- 💾 点击保存（Save）

---

## 📝 Cron 速查表

你的 Cron 组成部分：

```
0          = 分钟（:00）
9          = 小时（09:00）
15,25,28,29,30,31 = 日期（15、25、28-31 号）
*          = 月份（每个月）
*          = 周几（每天）
```

---

## 🧪 测试

### 本地验证（推荐先做）
```bash
# 在本地运行验证逻辑
python -m flows.currency_acquisition_flow
python -m flows.prepare_batch_flow
python -m flows.process_batch_flow
```

### Cloud 中测试
1. 登录 Prefect Cloud
2. 找到相应 Flow
3. 点击 "Run" 手动触发
4. 检查日志

---

## ✅ 设置完成清单

- [ ] 登录 Prefect Cloud (https://app.prefect.cloud)
- [ ] 为 currency-acquisition 添加 Schedule
- [ ] 为 prepare-batch 添加 Schedule  
- [ ] 为 process-batch 添加 Schedule
- [ ] 验证所有 Schedule 已启用
- [ ] 手动测试至少一个 Flow
- [ ] 确认时区设置正确
- [ ] 查看下一个预计运行时间

---

## 📌 重要提醒

⚠️ **确保至少有一个 Worker 在运行**
```bash
# 如果需要在本地运行
prefect worker start
```

⚠️ **检查时区** - 确保选择了正确的时区（Asia/Shanghai 或你的本地时区）

⚠️ **月末日期** - 某些月份没有 29、30、31 号，Cron 会自动跳过

---

## 📊 预期的执行流程

每个触发日期（15、25、28-31 号）：

```
09:00:00 → currency-acquisition 开始
          (获取汇率数据，~30-60秒)
09:30:00 → prepare-batch 开始
          (准备数据，~10秒)
10:00:00 → process-batch 开始
          (处理数据，~10秒)
10:15:00 → ✅ 所有任务完成
```

---

## 🔗 相关资源

- [完整设置指南](./SCHEDULE_SETUP_GUIDE.md)
- [Prefect Cloud UI](https://app.prefect.cloud)
- [Cron 语法参考](https://en.wikipedia.org/wiki/Cron#Overview)
- [时区列表](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones)

---

## 💡 需要帮助？

查看对应的文档：
1. **设置问题？** → 看 `SCHEDULE_SETUP_GUIDE.md`
2. **Cron 表达式疑问？** → 看本文的"Cron 速查表"
3. **Flow 执行问题？** → 检查 Prefect Cloud 的日志

---

**祝你配置顺利！** 🚀
